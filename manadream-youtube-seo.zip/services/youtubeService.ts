import { YOUTUBE_API_KEY } from '../constants';
import { SearchResultItem, YouTubeChannel, YouTubeVideo } from '../types';

interface ResolveResult {
  type: 'direct' | 'search' | 'none';
  id?: string;
  items?: SearchResultItem[];
}

export const resolveChannelInput = async (input: string): Promise<ResolveResult> => {
  const channelsUrl = `https://www.googleapis.com/youtube/v3/channels?part=id,snippet&key=${YOUTUBE_API_KEY}`;
  
  // 1. Direct ID check
  if (input.startsWith('UC') && input.length === 24) return { type: 'direct', id: input };

  // 2. URL parsing
  if (input.includes('youtube.com') || input.includes('youtu.be')) {
    const idMatch = input.match(/\/channel\/(UC[\w-]{22})/);
    if (idMatch) return { type: 'direct', id: idMatch[1] };
    
    let handle = '';
    const handleMatch = input.match(/@[\w\d_.-]+/);
    if (handleMatch) handle = handleMatch[0];
    
    const userMatch = input.match(/\/user\/([\w\d_.-]+)/);

    if (handle) {
      try {
        const res = await fetch(`${channelsUrl}&forHandle=${encodeURIComponent(handle)}`);
        const data = await res.json();
        if (data.items?.length) return { type: 'direct', id: data.items[0].id };
      } catch (e) { console.error(e); }
    }
    
    if (userMatch) {
      try {
        const res = await fetch(`${channelsUrl}&forUsername=${encodeURIComponent(userMatch[1])}`);
        const data = await res.json();
        if (data.items?.length) return { type: 'direct', id: data.items[0].id };
      } catch(e) { console.error(e); }
    }
  }

  // 3. Handle check (if input starts with @ but not a full URL)
  if (input.startsWith('@')) {
    try {
        const res = await fetch(`${channelsUrl}&forHandle=${encodeURIComponent(input)}`);
        const data = await res.json();
        if (data.items?.length) return { type: 'direct', id: data.items[0].id };
    } catch (e) { console.error(e); }
  }

  // 4. Fallback Search
  const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&maxResults=5&q=${encodeURIComponent(input)}&key=${YOUTUBE_API_KEY}`;
  try {
    const searchRes = await fetch(searchUrl);
    const searchData = await searchRes.json();
    if (searchData.items) return { type: 'search', items: searchData.items };
  } catch (e) { console.error(e); }

  return { type: 'none' };
};

export const fetchChannelDetails = async (channelId: string): Promise<YouTubeChannel> => {
  const url = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,brandingSettings&id=${channelId}&key=${YOUTUBE_API_KEY}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error("API Error");
  const data = await response.json();
  if (!data.items || !data.items.length) throw new Error("Channel not found.");
  
  // Flatten structure slightly for internal use if needed, but for now returning raw item
  return data.items[0];
};

export const fetchTopVideos = async (channelId: string): Promise<YouTubeVideo[]> => {
    // 1. Search for most popular videos of the channel
    const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=id&channelId=${channelId}&order=viewCount&maxResults=5&type=video&key=${YOUTUBE_API_KEY}`;
    
    const searchRes = await fetch(searchUrl);
    if (!searchRes.ok) {
        console.warn("Could not fetch top videos (Search quota might be exceeded)");
        return [];
    }
    
    const searchData = await searchRes.json();
    if (!searchData.items || !searchData.items.length) return [];

    const videoIds = searchData.items.map((item: any) => item.id.videoId).join(',');
    
    // 2. Get full details (statistics) for these videos
    const videosUrl = `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&id=${videoIds}&key=${YOUTUBE_API_KEY}`;
    const videosRes = await fetch(videosUrl);
    if (!videosRes.ok) return [];
    
    const videosData = await videosRes.json();
    return videosData.items || [];
};

export const calculateMockScores = (channelId: string) => {
  const seed = channelId.charCodeAt(0) + channelId.charCodeAt(channelId.length - 1);
  return {
      seoScore: Math.min(98, 60 + (seed % 40)),
      titleScore: Math.min(100, 70 + (seed % 30)),
      engScore: Math.min(100, 50 + (seed % 50)),
      tagScore: Math.min(100, 65 + (seed % 35)),
      descScore: Math.min(100, 80 + (seed % 20))
  };
};