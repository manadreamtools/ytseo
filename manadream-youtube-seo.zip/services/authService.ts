import { STORAGE_KEYS, DEFAULT_ADMIN } from '../constants';
import { User } from '../types';

export const loadUsers = (): User[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!stored) {
      const defaults = [DEFAULT_ADMIN];
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(defaults));
      return defaults;
    }
    let users = JSON.parse(stored);
    // Fix legacy admin if exists (from original code logic)
    users = users.map((u: User) => u.username === "admin" ? { ...u, username: "admin@gmail.com" } : u);
    return users;
  } catch (e) {
    return [DEFAULT_ADMIN];
  }
};

export const saveUser = (newUser: User): void => {
  const users = loadUsers();
  users.push(newUser);
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
};

export const getCurrentUser = (): User | null => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
};

export const loginUserSession = (user: User): void => {
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify({ username: user.username }));
};

export const logoutUser = (): void => {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
};