import { STORAGE_KEYS } from '../constants';
import { CRMContact } from '../types';

export const loadCRM = (username: string): CRMContact[] => {
  try {
    const key = `${STORAGE_KEYS.CRM_PREFIX}${username}`;
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

export const saveCRM = (username: string, data: CRMContact[]): void => {
  const key = `${STORAGE_KEYS.CRM_PREFIX}${username}`;
  localStorage.setItem(key, JSON.stringify(data));
};