import React, { useState } from 'react';
import { loadUsers, saveUser, loginUserSession } from '../../services/authService';
import { User } from '../../types';

interface SignUpProps {
  onSuccess: (user: User) => void;
  onToggle: () => void;
}

const SignUp: React.FC<SignUpProps> = ({ onSuccess, onToggle }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    const users = loadUsers();
    
    if (!username || !password || !confirmPass) {
      setError("All fields are required.");
      return;
    }

    if (!/@gmail\.com$/i.test(username)) {
      setError("Username must be a valid @gmail.com address.");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return;
    }

    if (password !== confirmPass) {
      setError("Passwords do not match.");
      return;
    }

    if (users.some(u => u.username === username)) {
      setError("Username already exists.");
      return;
    }

    const newUser: User = { username, password };
    saveUser(newUser);
    loginUserSession(newUser);
    onSuccess(newUser);
  };

  return (
    <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200 text-center">
      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-6">
        <i className="fa-solid fa-user-plus text-2xl text-green-600"></i>
      </div>
      <h2 className="text-2xl font-bold text-gray-900 mb-2">Create Account</h2>
      <p className="text-sm text-gray-500 mb-8">Choose a unique username that must be a <strong>@gmail.com</strong> address.</p>
      
      <div className="space-y-4 text-left">
        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1">New Username</label>
          <input 
            type="text" 
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-gray-50 border border-gray-300 rounded-lg p-3 focus:ring-red-500 focus:border-red-500 transition" 
            placeholder="e.g., yourname@gmail.com"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1">Password</label>
          <input 
            type="password" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-gray-50 border border-gray-300 rounded-lg p-3 focus:ring-red-500 focus:border-red-500 transition" 
            placeholder="Min 6 characters"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1">Confirm Password</label>
          <input 
            type="password" 
            value={confirmPass}
            onChange={(e) => setConfirmPass(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            className="w-full bg-gray-50 border border-gray-300 rounded-lg p-3 focus:ring-red-500 focus:border-red-500 transition" 
            placeholder="Retype password"
          />
        </div>
        {error && (
          <p className="text-red-600 text-sm animate-pulse">
            <i className="fa-solid fa-circle-exclamation mr-1"></i> {error}
          </p>
        )}
        
        <button 
          onClick={handleSubmit}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg transition shadow-md"
        >
          Sign Up
        </button>
      </div>
      <p className="mt-6 text-sm text-gray-500">
        Already have an account? 
        <button onClick={onToggle} className="text-red-600 hover:text-red-700 font-medium ml-1">
          Log In
        </button>
      </p>
    </div>
  );
};

export default SignUp;