import React, { useState } from 'react';
import { loadUsers, loginUserSession } from '../../services/authService';
import { User } from '../../types';

interface LoginProps {
  onSuccess: (user: User) => void;
  onToggle: () => void;
}

const Login: React.FC<LoginProps> = ({ onSuccess, onToggle }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    const users = loadUsers();
    const found = users.find(u => u.username === username.trim() && u.password === password);
    
    if (found) {
      loginUserSession(found);
      onSuccess(found);
    } else {
      setError("Invalid username or password.");
    }
  };

  return (
    <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-200 text-center">
      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 mb-6">
        <i className="fa-solid fa-lock text-2xl text-red-600"></i>
      </div>
      <h2 className="text-2xl font-bold text-gray-900 mb-2">Track Login</h2>
      <p className="text-sm text-gray-500 mb-8">Please log in to manage your relationships.</p>
      
      <div className="space-y-4 text-left">
        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1">Username</label>
          <input 
            type="text" 
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-gray-50 border border-gray-300 rounded-lg p-3 focus:ring-red-500 focus:border-red-500 transition" 
            placeholder="Username"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1">Password</label>
          <input 
            type="password" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            className="w-full bg-gray-50 border border-gray-300 rounded-lg p-3 focus:ring-red-500 focus:border-red-500 transition" 
            placeholder="Password"
          />
        </div>
        {error && (
          <p className="text-red-600 text-sm animate-pulse">
            <i className="fa-solid fa-circle-exclamation mr-1"></i> {error}
          </p>
        )}
        
        <button 
          onClick={handleSubmit}
          className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-lg transition shadow-md"
        >
          Login
        </button>
      </div>
      <p className="mt-6 text-sm text-gray-500">
        Don't have an account? 
        <button onClick={onToggle} className="text-red-600 hover:text-red-700 font-medium ml-1">
          Create one
        </button>
      </p>
    </div>
  );
};

export default Login;