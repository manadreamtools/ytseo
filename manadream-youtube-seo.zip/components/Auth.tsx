import React, { useState } from 'react';
import Login from './Auth/Login';
import SignUp from './Auth/SignUp';
import { User } from '../types';

interface AuthProps {
  onLogin: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLoginView, setIsLoginView] = useState(true);

  return (
    <div className="max-w-md mx-auto mt-12 animate-fade-in">
      {isLoginView ? (
        <Login 
          onSuccess={onLogin} 
          onToggle={() => setIsLoginView(false)} 
        />
      ) : (
        <SignUp 
          onSuccess={onLogin} 
          onToggle={() => setIsLoginView(true)} 
        />
      )}
    </div>
  );
};

export default Auth;