import React, { useState } from 'react';
import { CRMContact } from '../types';
import CRMStats from './CRM/CRMStats';
import CRMTable from './CRM/CRMTable';
import TaskModal from './CRM/TaskModal';

interface CRMProps {
  data: CRMContact[];
  onUpdate: (data: CRMContact[]) => void;
  onLogout: () => void;
}

const CRM: React.FC<CRMProps> = ({ data, onUpdate, onLogout }) => {
  const [scheduleTarget, setScheduleTarget] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);

  const handleExportImage = async () => {
    if (data.length === 0) {
      alert("Your CRM is empty!");
      return;
    }

    // Check if html2canvas is available
    const html2canvas = (window as any).html2canvas;
    if (!html2canvas) {
      alert("Export library is still loading. Please try again in a few seconds.");
      return;
    }

    setIsExporting(true);
    
    // Small delay to allow UI to update (show loading state) before capture
    setTimeout(async () => {
        try {
            const element = document.getElementById('crm-export-container');
            
            if (!element) {
                throw new Error("Export container not found");
            }

            const canvas = await html2canvas(element, {
                scale: 2, // Higher quality
                useCORS: true, // Allow loading cross-origin images (YouTube thumbnails)
                backgroundColor: '#f9fafb', // Match page background (bg-gray-50)
                logging: false,
                allowTaint: true
            });
            
            const link = document.createElement('a');
            link.download = `crm_tracker_${new Date().toISOString().split('T')[0]}.jpg`;
            link.href = canvas.toDataURL('image/jpeg', 0.9);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (e) {
            console.error("Export failed", e);
            alert("Failed to generate image. Please check console for details.");
        } finally {
            setIsExporting(false);
        }
    }, 100);
  };

  const updateContact = (id: string, field: keyof CRMContact, value: any) => {
    const updated = data.map(c => c.id === id ? { ...c, [field]: value } : c);
    onUpdate(updated);
  };

  const deleteContact = (id: string) => {
    if (window.confirm("Are you sure you want to remove this channel?")) {
      const updated = data.filter(c => c.id !== id);
      onUpdate(updated);
    }
  };

  const handleLogoutClick = () => {
    if (window.confirm("Are you sure you want to log out?")) {
      onLogout();
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Channel Relationship Tracker</h2>
          <p className="text-gray-600">Manage your influencers and content partnerships.</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto">
          <button 
            type="button"
            onClick={handleLogoutClick}
            className="flex-1 md:flex-none text-sm bg-gray-100 text-gray-700 hover:bg-gray-200 px-4 py-2 rounded-lg font-medium shadow-sm transition"
          >
             Logout
          </button>
          <button 
            type="button"
            onClick={handleExportImage}
            disabled={isExporting}
            className="flex-1 md:flex-none text-sm bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 px-4 py-2 rounded-lg font-medium shadow-sm flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isExporting ? (
                <i className="fa-solid fa-circle-notch fa-spin mr-2"></i>
            ) : (
                <i className="fa-solid fa-image mr-2"></i> 
            )}
            {isExporting ? "Exporting..." : "Export JPG"}
          </button>
        </div>
      </div>

      {/* Wrapper for Screenshot Capture */}
      <div id="crm-export-container" className="space-y-6 bg-gray-50 p-4 rounded-xl">
          <CRMStats data={data} />
          
          <CRMTable 
            data={data} 
            onUpdateField={updateContact}
            onDelete={deleteContact}
            onOpenSchedule={setScheduleTarget}
          />
      </div>

      {scheduleTarget && (
        <TaskModal 
          contact={data.find(c => c.id === scheduleTarget)!} 
          onClose={() => setScheduleTarget(null)}
          onUpdate={(updatedContact) => {
            updateContact(updatedContact.id, 'schedule', updatedContact.schedule);
          }}
        />
      )}
    </div>
  );
};

export default CRM;