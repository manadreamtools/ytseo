import React, { useEffect, useState } from 'react';

interface ScoreCardProps {
  title: string;
  score: number;
  icon: string;
  color: 'blue' | 'green' | 'purple' | 'orange';
  desc: string;
  label: string;
}

const ScoreCard: React.FC<ScoreCardProps> = ({ title, score, icon, color, desc, label }) => {
  const [displayScore, setDisplayScore] = useState(0);

  useEffect(() => {
    let start = 0;
    const duration = 1000;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      setDisplayScore(Math.floor(progress * (score - start) + start));

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [score]);

  const colorClasses = {
    blue: { bg: 'bg-blue-50', text: 'text-blue-500', bar: 'bg-blue-500', track: 'bg-blue-100', badge: 'bg-blue-200 text-blue-600' },
    green: { bg: 'bg-green-50', text: 'text-green-500', bar: 'bg-green-500', track: 'bg-green-100', badge: 'bg-green-200 text-green-600' },
    purple: { bg: 'bg-purple-50', text: 'text-purple-500', bar: 'bg-purple-500', track: 'bg-purple-100', badge: 'bg-purple-200 text-purple-600' },
    orange: { bg: 'bg-orange-50', text: 'text-orange-500', bar: 'bg-orange-500', track: 'bg-orange-100', badge: 'bg-orange-200 text-orange-600' },
  };

  const colors = colorClasses[color];

  return (
    <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-semibold text-gray-700">{title}</h3>
        <i className={`fa-solid ${icon} ${colors.text} ${colors.bg} p-2 rounded-lg`}></i>
      </div>
      <div className="relative pt-1">
        <div className="flex mb-2 items-center justify-between">
          <span className={`text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full ${colors.badge}`}>
            {label}
          </span>
          <div className="text-right">
            <span className={`text-xs font-semibold inline-block ${colors.text.replace('500', '600')}`}>
              {displayScore}%
            </span>
          </div>
        </div>
        <div className={`overflow-hidden h-2 mb-4 text-xs flex rounded ${colors.track}`}>
          <div 
            style={{ width: `${displayScore}%` }} 
            className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center ${colors.bar} transition-all duration-300`}
          ></div>
        </div>
      </div>
      <p className="text-xs text-gray-500">{desc}</p>
    </div>
  );
};

export default ScoreCard;