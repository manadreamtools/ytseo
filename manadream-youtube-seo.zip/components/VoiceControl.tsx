import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, FunctionDeclaration, Type } from "@google/genai";
import { createBlob, decodeAudioData, base64ToUint8Array, PCM_FREQUENCY, AUDIO_OUT_FREQUENCY } from '../utils/audioUtils';

interface VoiceControlProps {
  onNavigate: (view: 'dashboard' | 'crm') => void;
  onAnalyze: (query: string) => void;
}

const VoiceControl: React.FC<VoiceControlProps> = ({ onNavigate, onAnalyze }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [volume, setVolume] = useState(0);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  
  // Output Audio Refs
  const outputContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const scheduledSourcesRef = useRef<AudioBufferSourceNode[]>([]);

  // Session Ref (kept in ref to access inside closures)
  const sessionRef = useRef<any>(null);
  
  // Tool Definitions
  const tools: FunctionDeclaration[] = [
    {
      name: 'navigate_to_view',
      description: 'Switch the application screen to either the Dashboard or the Login/Tracking page.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          view: { 
            type: Type.STRING, 
            enum: ['dashboard', 'crm'],
            description: 'The target view. "dashboard" for analysis, "crm" for login or tracking.' 
          },
        },
        required: ['view'],
      },
    },
    {
      name: 'analyze_channel',
      description: 'Analyze a YouTube channel by providing a name, ID, or handle.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          query: { 
            type: Type.STRING, 
            description: 'The YouTube channel name, handle (e.g. @MrBeast), or Channel ID.' 
          },
        },
        required: ['query'],
      },
    }
  ];

  const stopAudio = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    if (outputContextRef.current) {
      outputContextRef.current.close();
      outputContextRef.current = null;
    }
    
    // Stop all scheduled audio
    scheduledSourcesRef.current.forEach(source => {
        try { source.stop(); } catch(e) {}
    });
    scheduledSourcesRef.current = [];
    setIsActive(false);
    setIsConnecting(false);
    setVolume(0);
  };

  const startSession = async () => {
    try {
      setIsConnecting(true);
      
      // 1. Setup Audio Input
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { sampleRate: PCM_FREQUENCY } });
      streamRef.current = stream;
      
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: PCM_FREQUENCY });
      audioContextRef.current = audioContext;
      
      const source = audioContext.createMediaStreamSource(stream);
      inputSourceRef.current = source;
      
      // Visualizer setup
      const analyzer = audioContext.createAnalyser();
      analyzer.fftSize = 256;
      source.connect(analyzer);
      const dataArray = new Uint8Array(analyzer.frequencyBinCount);
      
      const updateVolume = () => {
          if (!isActive && !isConnecting) return;
          analyzer.getByteFrequencyData(dataArray);
          const avg = dataArray.reduce((a, b) => a + b) / dataArray.length;
          setVolume(avg);
          requestAnimationFrame(updateVolume);
      };
      updateVolume();

      // Processor for streaming data
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;
      
      source.connect(processor);
      processor.connect(audioContext.destination);

      // 2. Setup Audio Output
      outputContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: AUDIO_OUT_FREQUENCY });
      nextStartTimeRef.current = 0;

      // 3. Initialize Gemini Client
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // 4. Connect to Live API
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          tools: [{ functionDeclarations: tools }],
          systemInstruction: "You are a helpful assistant for the 'ManaDream YouTube SEO' app. You can navigate views and analyze channels. Be concise and energetic. If the user asks to analyze a channel, confirm you are doing it and call the function.",
        },
        callbacks: {
          onopen: () => {
            console.log("Gemini Live Connected");
            setIsConnecting(false);
            setIsActive(true);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Audio Output
            const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData && outputContextRef.current) {
              const ctx = outputContextRef.current;
              const audioBuffer = await decodeAudioData(
                base64ToUint8Array(audioData),
                ctx,
                AUDIO_OUT_FREQUENCY
              );
              
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              
              const now = ctx.currentTime;
              // Ensure we schedule in the future
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, now);
              
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              
              scheduledSourcesRef.current.push(source);
              
              source.onended = () => {
                 const idx = scheduledSourcesRef.current.indexOf(source);
                 if (idx > -1) scheduledSourcesRef.current.splice(idx, 1);
              };
            }

            // Handle Interruption
            if (message.serverContent?.interrupted) {
                scheduledSourcesRef.current.forEach(s => {
                    try { s.stop(); } catch(e) {}
                });
                scheduledSourcesRef.current = [];
                if (outputContextRef.current) nextStartTimeRef.current = outputContextRef.current.currentTime;
            }

            // Handle Tool Calls
            if (message.toolCall) {
               for (const fc of message.toolCall.functionCalls) {
                   let result: any = { ok: true };
                   
                   if (fc.name === 'navigate_to_view') {
                       const view = (fc.args as any).view;
                       onNavigate(view);
                       result = { result: `Navigated to ${view}` };
                   }
                   
                   if (fc.name === 'analyze_channel') {
                       const query = (fc.args as any).query;
                       onAnalyze(query);
                       result = { result: `Analyzing channel: ${query}` };
                   }

                   // Send Tool Response back to model
                   sessionPromise.then(session => {
                       session.sendToolResponse({
                           functionResponses: [{
                               id: fc.id,
                               name: fc.name,
                               response: result
                           }]
                       });
                   });
               }
            }
          },
          onclose: () => {
            console.log("Session closed");
            stopAudio();
          },
          onerror: (err) => {
            console.error("Session error", err);
            stopAudio();
          }
        }
      });

      sessionRef.current = sessionPromise;

      // Hook up the audio processor to the session
      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        const pcmBlob = createBlob(inputData);
        
        sessionPromise.then(session => {
            session.sendRealtimeInput({ media: pcmBlob });
        });
      };

    } catch (err) {
      console.error("Failed to start voice session:", err);
      setIsConnecting(false);
      stopAudio();
    }
  };

  const toggleSession = () => {
    if (isActive || isConnecting) {
      stopAudio();
    } else {
      startSession();
    }
  };

  // Cleanup on unmount
  useEffect(() => {
      return () => {
          stopAudio();
      };
  }, []);

  return (
    <div className="fixed bottom-6 right-6 z-[100]">
      <button
        onClick={toggleSession}
        className={`relative flex items-center justify-center w-16 h-16 rounded-full shadow-xl transition-all duration-300 ${
          isActive 
            ? 'bg-red-600 text-white' 
            : isConnecting 
                ? 'bg-gray-200 text-gray-500'
                : 'bg-white text-red-600 hover:scale-105'
        }`}
      >
        {/* Ripple effect for speaking/active */}
        {isActive && (
          <span 
            className="absolute inset-0 rounded-full bg-red-600 opacity-30 animate-ping"
            style={{ animationDuration: `${Math.max(0.5, 2 - (volume / 50))}s` }}
          ></span>
        )}
        
        <i className={`fa-solid ${isConnecting ? 'fa-circle-notch fa-spin' : isActive ? 'fa-microphone-lines' : 'fa-microphone'} text-2xl relative z-10`}></i>
      </button>
      
      {isActive && (
        <div className="absolute bottom-20 right-0 bg-gray-900 text-white text-xs py-1 px-3 rounded-lg whitespace-nowrap shadow-lg">
           Listening... Say "Analyze MrBeast"
        </div>
      )}
    </div>
  );
};

export default VoiceControl;