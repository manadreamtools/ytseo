import React, { useState, useRef, useEffect } from 'react';
import { resolveChannelInput, fetchChannelDetails, calculateMockScores, fetchTopVideos } from '../services/youtubeService';
import { SearchResultItem, YouTubeChannel, Scores, CRMContact, User, YouTubeVideo } from '../types';
import ScoreCard from './Dashboard/ScoreCard';

interface DashboardProps {
  onAddToCrm: (contact: CRMContact) => void;
  user: User | null;
  autoSearchQuery?: string | null;
  onSearchComplete?: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onAddToCrm, user, autoSearchQuery, onSearchComplete }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchResults, setSearchResults] = useState<SearchResultItem[] | null>(null);
  const [channelData, setChannelData] = useState<YouTubeChannel | null>(null);
  const [scores, setScores] = useState<Scores | null>(null);
  const [topVideos, setTopVideos] = useState<YouTubeVideo[]>([]);
  
  const errorRef = useRef<HTMLDivElement>(null);

  // Handle Auto Search from Voice
  useEffect(() => {
      if (autoSearchQuery) {
          setInput(autoSearchQuery);
          handleAnalyze(autoSearchQuery);
          if (onSearchComplete) onSearchComplete();
      }
  }, [autoSearchQuery]);

  const handleAnalyze = async (overrideInput?: string) => {
    const query = overrideInput || input.trim();
    if (!query) {
      setError("Please enter a YouTube Channel ID, Handle, or URL.");
      pulseError();
      return;
    }

    setLoading(true);
    setError(null);
    setSearchResults(null);
    setChannelData(null);
    setTopVideos([]);

    try {
      const resolved = await resolveChannelInput(query);

      if (resolved.type === 'direct' && resolved.id) {
        await loadChannel(resolved.id);
      } else if (resolved.type === 'search' && resolved.items) {
        setSearchResults(resolved.items);
      } else {
        throw new Error("No channels found. Try a specific Channel ID or Check Spelling.");
      }
    } catch (err: any) {
      setError(err.message || "Failed to fetch channel data.");
      pulseError();
    } finally {
      setLoading(false);
    }
  };

  const loadChannel = async (id: string) => {
    try {
      setLoading(true);
      setSearchResults(null);
      setTopVideos([]);

      // Fetch channel details and top videos concurrently
      const [details, videos] = await Promise.all([
        fetchChannelDetails(id),
        fetchTopVideos(id)
      ]);
      
      const calculatedScores = calculateMockScores(id);
      
      setChannelData(details);
      setTopVideos(videos);
      setScores(calculatedScores);
      
      // Auto add to CRM if user is logged in
      if (user) {
        const newContact: CRMContact = {
            id: details.id,
            title: details.snippet.title,
            thumbnail: details.snippet.thumbnails.default.url,
            subs: parseInt(details.statistics.subscriberCount, 10),
            seoScore: calculatedScores.seoScore,
            status: 'lead',
            email: '',
            notes: '',
            dateAdded: new Date().toISOString(),
            schedule: [
                { id: Date.now().toString() + '1', text: "**Long Video Upload** planning phase", completed: false, dateCreated: new Date().toISOString() },
                { id: Date.now().toString() + '2', text: "**Shorts Upload** prep (3 videos)", completed: false, dateCreated: new Date().toISOString() },
            ]
        };
        onAddToCrm(newContact);
      }

    } catch (err) {
      setError("Could not load channel details.");
      pulseError();
    } finally {
      setLoading(false);
    }
  };

  const pulseError = () => {
    if (errorRef.current) {
      errorRef.current.classList.add('animate-pulse');
      setTimeout(() => errorRef.current?.classList.remove('animate-pulse'), 500);
    }
  };

  const formatNumber = (num: string | number) => {
    const n = typeof num === 'string' ? parseInt(num, 10) : num;
    return new Intl.NumberFormat('en-US', { notation: "compact", compactDisplay: "short" }).format(n);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      {/* Intro */}
      <div className="text-center space-y-2 mb-8">
        <h2 className="text-3xl font-extrabold text-gray-900">Channel Performance Analyzer</h2>
        <p className="text-gray-600">Track subscribers, analyze keywords, and calculate SEO health.</p>
      </div>

      {/* Input Section */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">
              Channel URL, ID, or Handle
            </label>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-grow">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAnalyze()}
                  placeholder="@ManaDream, UC..., or Search by Name"
                  className="w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-red-500 focus:border-red-500 block p-3 pl-10 transition"
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <i className="fa-solid fa-search text-gray-400"></i>
                </div>
              </div>
              <button
                onClick={() => handleAnalyze()}
                disabled={loading}
                className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg transition shadow-md flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {loading ? (
                   <i className="fa-solid fa-circle-notch fa-spin"></i>
                ) : (
                   <><span>Analyze</span><i className="fa-solid fa-arrow-right"></i></>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div ref={errorRef} className="bg-red-50 border-l-4 border-red-500 p-4 rounded-md">
          <div className="flex">
            <div className="flex-shrink-0">
              <i className="fa-solid fa-circle-exclamation text-red-500"></i>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      {/* Search Results List */}
      {searchResults && (
        <div className="space-y-3 animate-fade-in">
          <h3 className="text-lg font-bold text-gray-800 px-1">Search Results</h3>
          <div className="grid grid-cols-1 gap-3">
            {searchResults.map((item) => (
              <div 
                key={item.id.channelId}
                onClick={() => loadChannel(item.id.channelId)}
                className="bg-white p-4 rounded-xl border border-gray-200 cursor-pointer hover:-translate-y-0.5 hover:shadow-md transition flex items-center gap-4"
              >
                <img 
                  src={item.snippet.thumbnails.default.url} 
                  alt="Thumbnail"
                  className="w-12 h-12 rounded-full object-cover bg-gray-100"
                  onError={(e) => e.currentTarget.src = 'https://placehold.co/48x48/d1d5db/4b5563?text=YT'}
                />
                <div className="overflow-hidden">
                  <h4 className="font-bold text-gray-900 truncate">{item.snippet.channelTitle || item.snippet.title}</h4>
                  <p className="text-xs text-gray-500 truncate">{item.snippet.description || 'No description available'}</p>
                </div>
                <i className="fa-solid fa-chevron-right ml-auto text-gray-300"></i>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Results Section */}
      {channelData && scores && (
        <div className="space-y-6 animate-fade-in">
          {/* Profile Card */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 relative overflow-hidden">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
              <img 
                src={channelData.snippet.thumbnails.medium.url} 
                alt="Profile" 
                className="w-24 h-24 rounded-full border-4 border-gray-50 shadow-md object-cover"
                onError={(e) => e.currentTarget.src = 'https://placehold.co/96x96/d1d5db/4b5563?text=YT'}
              />
              <div className="text-center sm:text-left flex-grow">
                <h2 className="text-2xl font-bold text-gray-900">{channelData.snippet.title}</h2>
                <p className="text-sm text-gray-500 font-mono mb-3">ID: {channelData.id}</p>
                
                <div className="flex flex-wrap justify-center sm:justify-start gap-4 text-sm">
                  <div className="bg-gray-100 px-3 py-1 rounded-full">
                    <i className="fa-solid fa-users text-red-600 mr-1"></i>
                    <span className="font-bold text-gray-800">{formatNumber(channelData.statistics.subscriberCount)}</span> Subscribers
                  </div>
                  <div className="bg-gray-100 px-3 py-1 rounded-full">
                    <i className="fa-solid fa-eye text-red-600 mr-1"></i>
                    <span className="font-bold text-gray-800">{formatNumber(channelData.statistics.viewCount)}</span> Views
                  </div>
                  <div className="bg-gray-100 px-3 py-1 rounded-full">
                    <i className="fa-solid fa-video text-red-600 mr-1"></i>
                    <span className="font-bold text-gray-800">{formatNumber(channelData.statistics.videoCount)}</span> Videos
                  </div>
                </div>
              </div>
              {/* Overall Score Badge */}
              <div className="flex flex-col items-center justify-center bg-red-50 p-4 rounded-xl border border-red-100 min-w-[100px] mt-8 sm:mt-0">
                <span className="text-xs font-bold text-red-600 uppercase">SEO Score</span>
                <span className="text-4xl font-extrabold text-gray-900">{scores.seoScore}%</span>
              </div>
            </div>
          </div>

          {/* Detailed Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ScoreCard 
              title="Engagement Rate" 
              score={scores.engScore} 
              icon="fa-chart-line" 
              color="blue"
              desc="Based on views vs. subscribers ratio."
              label="Good"
            />
            <ScoreCard 
              title="Title Optimization" 
              score={scores.titleScore} 
              icon="fa-heading" 
              color="green"
              desc="Keyword density in recent titles."
              label="High"
            />
            <ScoreCard 
              title="Tag Health" 
              score={scores.tagScore} 
              icon="fa-tags" 
              color="purple"
              desc="Relevance of tags to channel niche."
              label="Average"
            />
            <ScoreCard 
              title="Description SEO" 
              score={scores.descScore} 
              icon="fa-align-left" 
              color="orange"
              desc="Length and keyword richness."
              label="Solid"
            />
          </div>

          {/* Top Popular Videos Section */}
          {topVideos.length > 0 && (
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                  <i className="fa-brands fa-youtube text-red-600 mr-2"></i> Most Popular Videos
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {topVideos.map(video => (
                  <a 
                      key={video.id} 
                      href={`https://www.youtube.com/watch?v=${video.id}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="group block"
                  >
                    <div className="relative aspect-video rounded-lg overflow-hidden mb-2 bg-gray-100">
                      <img 
                          src={video.snippet.thumbnails.medium.url} 
                          alt={video.snippet.title} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute bottom-1 right-1 bg-black/70 text-white text-[10px] px-1 rounded">
                         {formatNumber(video.statistics.viewCount)}
                      </div>
                    </div>
                    <h4 className="font-semibold text-gray-900 text-sm line-clamp-2 mb-1 group-hover:text-red-600 transition-colors" title={video.snippet.title}>
                      {video.snippet.title}
                    </h4>
                    <p className="text-xs text-gray-400">
                       {new Date(video.snippet.publishedAt).toLocaleDateString()}
                    </p>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Dashboard;