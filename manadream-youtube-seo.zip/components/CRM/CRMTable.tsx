import React from 'react';
import { CRMContact } from '../../types';

interface CRMTableProps {
  data: CRMContact[];
  onUpdateField: (id: string, field: keyof CRMContact, value: any) => void;
  onDelete: (id: string) => void;
  onOpenSchedule: (id: string) => void;
}

const CRMTable: React.FC<CRMTableProps> = ({ data, onUpdateField, onDelete, onOpenSchedule }) => {
  if (data.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
        <div className="text-gray-400 mb-3"><i className="fa-solid fa-address-book text-4xl"></i></div>
        <h3 className="text-lg font-medium text-gray-900">Your CRM is empty</h3>
        <p className="text-gray-500">Analyze a channel and it will automatically be added here.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Channel</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stats</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Handler & Details</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {data.map((contact) => {
               let statusColor = 'gray';
               if (contact.status === 'contacted') statusColor = 'blue';
               if (contact.status === 'negotiating') statusColor = 'yellow';
               if (contact.status === 'partner') statusColor = 'green';

               return (
                <tr key={contact.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10">
                        <img 
                          className="h-10 w-10 rounded-full object-cover" 
                          src={contact.thumbnail} 
                          alt="" 
                          onError={(e) => e.currentTarget.src = 'https://placehold.co/40x40/d1d5db/4b5563?text=YT'}
                        />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900 truncate max-w-[150px]" title={contact.title}>{contact.title}</div>
                        <div className="text-xs text-gray-500">Score: {contact.seoScore}% | Added: {new Date(contact.dateAdded).toLocaleDateString()}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 font-bold">{new Intl.NumberFormat('en-US', { notation: "compact", compactDisplay: "short" }).format(contact.subs)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-${statusColor}-100 text-${statusColor}-800`}>
                      <select 
                        value={contact.status} 
                        onChange={(e) => onUpdateField(contact.id, 'status', e.target.value)}
                        className="bg-transparent border-none focus:ring-0 p-0 text-xs font-semibold cursor-pointer outline-none"
                      >
                        <option value="lead">Lead</option>
                        <option value="contacted">Contacted</option>
                        <option value="negotiating">Negotiating</option>
                        <option value="partner">Partner</option>
                      </select>
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-2">
                      <input 
                        type="email" 
                        placeholder="Handler Email" 
                        value={contact.email || ''} 
                        onChange={(e) => onUpdateField(contact.id, 'email', e.target.value)}
                        className="text-xs border-gray-200 rounded p-1 w-full focus:ring-red-500 focus:border-red-500 border"
                      />
                      <input 
                        type="text" 
                        placeholder="Relationship Notes" 
                        value={contact.notes || ''} 
                        onChange={(e) => onUpdateField(contact.id, 'notes', e.target.value)}
                        className="text-xs border-gray-200 rounded p-1 w-full focus:ring-red-500 focus:border-red-500 border"
                      />
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-y-2">
                    <button 
                      onClick={() => onOpenSchedule(contact.id)}
                      className="text-white bg-blue-500 hover:bg-blue-600 px-3 py-1 rounded-full text-xs font-medium transition shadow-md w-full"
                    >
                      <i className="fa-solid fa-calendar-alt mr-1"></i> Schedule ({contact.schedule.length})
                    </button>
                    <button 
                      onClick={() => onDelete(contact.id)}
                      className="text-red-600 hover:text-red-900 px-3 py-1 text-xs w-full block bg-red-50 rounded-full"
                    >
                      <i className="fa-solid fa-trash mr-1"></i> Remove
                    </button>
                  </td>
                </tr>
               );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CRMTable;