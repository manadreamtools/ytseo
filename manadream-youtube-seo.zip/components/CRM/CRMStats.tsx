import React, { useMemo } from 'react';
import { CRMContact } from '../../types';

interface CRMStatsProps {
  data: CRMContact[];
}

const CRMStats: React.FC<CRMStatsProps> = ({ data }) => {
  const stats = useMemo(() => {
    let totalSubs = 0;
    let totalSeoScore = 0;
    let contactedCount = 0;
    
    data.forEach(contact => {
        totalSubs += contact.subs || 0; 
        totalSeoScore += contact.seoScore || 0; 
        if (['contacted', 'negotiating', 'partner'].includes(contact.status)) {
            contactedCount++;
        }
    });

    const totalChannels = data.length;
    const avgSeo = totalChannels > 0 ? (totalSeoScore / totalChannels).toFixed(1) : 0;
    
    return { totalChannels, totalSubs, avgSeo, contactedCount };
  }, [data]);

  const formatLargeNumber = (num: number) => {
      return new Intl.NumberFormat('en-US', { notation: "compact", compactDisplay: "short" }).format(num);
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between">
          <div>
              <p className="text-sm font-medium text-gray-500">Main Channels</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalChannels}</p>
          </div>
          <i className="fa-solid fa-star text-3xl text-red-300"></i>
      </div>
      
      <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between">
          <div>
              <p className="text-sm font-medium text-gray-500">Total Subscribers</p>
              <p className="text-2xl font-bold text-gray-900">{formatLargeNumber(stats.totalSubs)}</p>
          </div>
          <i className="fa-solid fa-users text-3xl text-blue-300"></i>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between">
          <div>
              <p className="text-sm font-medium text-gray-500">Avg. SEO Score</p>
              <p className="text-2xl font-bold text-gray-900">{stats.avgSeo}%</p>
          </div>
          <i className="fa-solid fa-chart-line text-3xl text-green-300"></i>
      </div>

      <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 flex items-center justify-between">
          <div>
              <p className="text-sm font-medium text-gray-500">Channels Contacted</p>
              <p className="text-2xl font-bold text-gray-900">{stats.contactedCount}</p>
          </div>
          <i className="fa-solid fa-handshake text-3xl text-purple-300"></i>
      </div>
    </div>
  );
};

export default CRMStats;