import React, { useState } from 'react';
import { CRMContact, Task } from '../../types';

interface TaskModalProps {
  contact: CRMContact;
  onClose: () => void;
  onUpdate: (contact: CRMContact) => void;
}

const TaskModal: React.FC<TaskModalProps> = ({ contact, onClose, onUpdate }) => {
  const [newTaskText, setNewTaskText] = useState('');

  const sortedTasks = [...contact.schedule].sort((a, b) => {
    if (a.completed && !b.completed) return 1;
    if (!a.completed && b.completed) return -1;
    return 0;
  });

  const handleAddTask = () => {
    if (!newTaskText.trim()) return;

    const newTask: Task = {
      id: Date.now().toString(),
      text: newTaskText,
      completed: false,
      dateCreated: new Date().toISOString()
    };

    const updatedSchedule = [newTask, ...contact.schedule];
    onUpdate({ ...contact, schedule: updatedSchedule });
    setNewTaskText('');
  };

  const toggleTask = (taskId: string) => {
    const updatedSchedule = contact.schedule.map(t => 
      t.id === taskId ? { ...t, completed: !t.completed } : t
    );
    onUpdate({ ...contact, schedule: updatedSchedule });
  };

  const deleteTask = (taskId: string) => {
    const updatedSchedule = contact.schedule.filter(t => t.id !== taskId);
    onUpdate({ ...contact, schedule: updatedSchedule });
  };

  const formatTaskText = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <span key={index} className="font-semibold text-red-600">{part.slice(2, -2)}</span>;
      }
      return part;
    });
  };

  return (
    <div className="fixed inset-0 bg-gray-900/50 flex items-center justify-center z-[60] backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-white p-6 rounded-xl shadow-2xl max-w-lg w-full transform transition-all scale-100">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <i className="fa-solid fa-calendar-alt text-red-600"></i> Schedule for {contact.title}
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition">
            <i className="fa-solid fa-times text-xl"></i>
          </button>
        </div>

        <p className="text-xs text-gray-500 mb-4">Channel ID: {contact.id}</p>

        <div className="space-y-4">
          <div className="flex gap-3">
            <input 
              type="text" 
              placeholder="New task: Prep thumbnails..." 
              value={newTaskText}
              onChange={(e) => setNewTaskText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddTask()}
              className="flex-grow bg-gray-50 border border-gray-300 rounded-lg p-3 text-sm focus:ring-red-500 focus:border-red-500"
            />
            <button 
              onClick={handleAddTask}
              disabled={!newTaskText.trim()}
              className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition shadow-md disabled:opacity-50"
            >
              <i className="fa-solid fa-plus"></i> Add
            </button>
          </div>

          <ul className="divide-y divide-gray-100 max-h-80 overflow-y-auto">
            {sortedTasks.length === 0 ? (
              <li className="text-center text-gray-500 text-sm italic py-4">No tasks scheduled.</li>
            ) : (
              sortedTasks.map(task => (
                <li key={task.id} className="py-3 flex items-center justify-between transition group">
                  <div className="flex items-center space-x-3 flex-grow min-w-0">
                    <input 
                      type="checkbox" 
                      checked={task.completed} 
                      onChange={() => toggleTask(task.id)}
                      className="h-4 w-4 text-red-600 border-gray-300 rounded focus:ring-red-500 cursor-pointer"
                    />
                    <span className={`text-sm text-gray-800 truncate ${task.completed ? 'line-through text-gray-400' : ''}`}>
                      {formatTaskText(task.text)}
                    </span>
                  </div>
                  <button 
                    onClick={() => deleteTask(task.id)}
                    className="text-gray-400 hover:text-red-600 transition p-1 rounded ml-2"
                  >
                    <i className="fa-solid fa-xmark"></i>
                  </button>
                </li>
              ))
            )}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default TaskModal;